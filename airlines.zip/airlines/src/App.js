import React from 'react';
import logo from './logo.svg';
import './App.css';
import {BrowserRouter as Router, Switch, Route} from 'react-router-dom';
import { browserHistory } from 'react-router'; 

import HomePage from './components/HomePage/HomePage';
import FlightLists from './components/FlightLists/FlightList';
import PassengersLists from './components/Passengers/PassengersList';
import PassengerCheckinDetail from './components/Passengers/PassengerCheckinDetail';
import LoginPage from './components/LoginPage/Login';
import AdminHomePage from './components/AdminHomePage/AdminHomePage';
import StaffHomePage from './components/StaffHomePage/StaffHomePage';
import Services from './components/Services/Services';


function App() {
  return (
    <div className="App">
      <Router > 
        <Route exact path="/" component={HomePage} />
        <Route path="/Login" component={LoginPage} />
        <Route path="/AdminHomePage" component={AdminHomePage} />
        <Route path="/StaffHomePage" component={StaffHomePage} />
        <Route path="/FlightLists" component={FlightLists} />
        <Route path="/PassengersLists/:flightNo" component={PassengersLists}/>
        <Route path="/PassengerCheckinDetail/:flightNo" component={PassengerCheckinDetail}/>
        <Route path="/Services/Services/:flightNo" component={Services}/>
      </Router>
      </div>
    
  );
}

export default App;
