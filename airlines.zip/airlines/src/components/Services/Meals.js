import React, {Component} from 'react';
import {Modal, Button, Row, Col, Form, ModalBody} from 'react-bootstrap';
import axios from 'axios';

class Meals extends Component {
  constructor(props){
    super(props);
    this.state = {      
      special_meal: ''
    }  
   
  }
  changeHandler = (e) => {
    this.setState({
        [e.target.name]: e.target.value
    });
}

handleSubmit =(e, flightUpdate) => {
  e.preventDefault();
  const addMeals = {
     special_meals: this.props.flightLists.special_meals.concat(this.state.special_meal)

 }
       axios
          .patch(
              `http://localhost:3000/flightLists/${this.props.flightLists.id}`, addMeals
          )
          .then(res => {
             // this.props.getPassengerList();
           //  closeUpdatePassengerModal();
           this.props.onHide();
          });
         
   }

   handleDelete =(e, flightUpdate) => {
    e.preventDefault();   
    this.state = {
      spMeal: this.props.flightLists.special_meals
    }   
    const test = this.props.flightLists.special_meals.splice(flightUpdate, 1)
    const removeService = {
       special_meals: this.state.spMeal
  
   }
         axios
            .patch(
                `http://localhost:3000/flightLists/${this.props.flightLists.id}`, removeService
            )
            .then(res => {              
             this.props.onHide();
            });  
     }

    render() {     
    return (
       
             <Modal
                {...this.props}
                size="lg"
                aria-labelledby="contained-modal-title-vcenter"
                centered
              >
                <Modal.Header closeButton>
                  <Modal.Title id="contained-modal-title-vcenter">
                    Add/Delete Special Meals here....
                  </Modal.Title>
                </Modal.Header>
                <ModalBody>
                <form onSubmit={e => this.handleDelete(e, this.props.flightLists)}>
                  <table  className="table">
                    <thead  className="thead-dark">
                      <tr>
                          <th scope="col">Special Meals</th>  
                          <th scope="col">Delete Meals</th>                                 
                      </tr>
                   </thead>
                   <tbody>
                     {this.props.flightLists && this.props.flightLists.special_meals.map((data, index)=>{                       
                       return (
                       <tr>
                         <td>{data}</td>
                         <td><Button variant="primary" type="submit" onClick={(e)=> this.handleDelete(e, index)}  >Delete</Button></td>
                       </tr>
                       )
                     })}                   
                   </tbody>
                  </table>
                  </form>
                  <form onSubmit={e => this.handleSubmit(e, this.props.flightLists)}>
                    <input type="text"
                      name="special_meal"
                      placeholder="Meal"
                      value={this.state.special_meal}
                      onChange={e => this.changeHandler(e)} />
                    <Button variant="outline-primary" type="submit" >Add</Button>
                  </form>
                </ModalBody>

         </Modal>
      )
    }
}

export default Meals;