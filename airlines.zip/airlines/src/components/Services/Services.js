import React, {Component} from 'react';
import {Modal, Button, Row, Col, Form, ModalBody} from 'react-bootstrap';
import axios from 'axios';

class Services extends Component {
  constructor(props){
    super(props);
    this.state = {      
      special_service: ''
    }  
   
  }
  
  changeHandler = (e) => {
    this.setState({
        [e.target.name]: e.target.value
    });
}

handleSubmit =(e, flightUpdate) => {
  e.preventDefault();
  const addService = {
     special_services: this.props.flightLists.special_services.concat(this.state.special_service)

 }
       axios
          .patch(
              `http://localhost:3000/flightLists/${this.props.flightLists.id}`, addService
          )
          .then(res => {
             // this.props.getPassengerList();
           //  closeUpdatePassengerModal();
           this.props.onHide();
          });

          console.log("update save clicked", addService)
   }

   handleDelete =(e, flightUpdate) => {
    e.preventDefault();
    console.log('e', e);
    console.log('del', flightUpdate);
    this.state = {
      spService: this.props.flightLists.special_services
    }
    console.log('sp', this.state.spService);
    const test = this.props.flightLists.special_services.splice(flightUpdate, 1)
    const removeService = {
       special_services: this.state.spService
  
   }
         axios
            .patch(
                `http://localhost:3000/flightLists/${this.props.flightLists.id}`, removeService
            )
            .then(res => {
               // this.props.getPassengerList();
             //  closeUpdatePassengerModal();
             this.props.onHide();
            });
  
            console.log("update save clicked", removeService)
            console.log("update save clicked", this.state.spService)
     }

    render() {
      console.log('state of sp', this.state.special_service);
      console.log('Services props',  this.props.flightLists );
    return (
       
             <Modal
                {...this.props}
                size="lg"
                aria-labelledby="contained-modal-title-vcenter"
                centered
              >
                <Modal.Header closeButton>
                  <Modal.Title id="contained-modal-title-vcenter">
                    Add/Update/Delete Special Services here....
                  </Modal.Title>
                </Modal.Header>
                <ModalBody>
                <form onSubmit={e => this.handleDelete(e, this.props.flightLists)}>
                  <table  className="table">
                    <thead  className="thead-dark">
                      <tr>
                          <th scope="col">Special Service</th>  
                          <th scope="col">Delete Service</th>                                 
                      </tr>
                   </thead>
                   <tbody>
                     {this.props.flightLists && this.props.flightLists.special_services.length > 0 && this.props.flightLists.special_services.map((data, index)=>{
                       console.log('data', data, index);
                       return (
                       <tr>
                         <td>{data}</td>
                         <td><Button variant="primary" type="submit" onClick={(e)=> this.handleDelete(e, index)}>Delete</Button></td>
                       </tr>
                       )
                     })}                    
                   
                   </tbody>
                  </table>
                  </form>
                  <form onSubmit={e => this.handleSubmit(e, this.props.flightLists)}>
                    <input type="text"
                      name="special_service"
                      placeholder="Service"
                      value={this.state.special_service}
                      onChange={e => this.changeHandler(e)} />
                    <Button variant="outline-primary" type="submit" >Add</Button>
                  </form>
                </ModalBody>

         </Modal>
      )
    }
}

export default Services;