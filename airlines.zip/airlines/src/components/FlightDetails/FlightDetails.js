import React, {Component} from 'react';


class FlightDetails extends Component { 

}


export default FlightDetails;