import React, {Component} from 'react';
import {Modal, Button, Row, Col, Form, ModalBody} from 'react-bootstrap';
import axios from 'axios';

class ModifyServices extends Component {

    constructor(props) {
        super(props);
        this.state = {selectedValue: '', selectedMeal: ''};
    
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);   
        this.handleMealChange = this.handleMealChange.bind(this);     
      }
    
    handleChange(event) {
        this.setState({
            selectedValue: event.target.value
        });              
      }
       
      handleMealChange(event) {       
        this.setState({
            selectedMeal: event.target.value
        });              
      }
      handleSubmit(event, p) {        
        event.preventDefault(); 
        console.log('handleSubmit',this.state.selectedValue, this.state.selectedMeal );   
        const modifyService = {
            special_services: (this.state.selectedValue) ?  this.state.selectedValue : this.props.passenger.special_services,
            special_meals: (this.state.selectedMeal) ?  this.state.selectedMeal : this.props.passenger.selectedMeal          
        }
        console.log('modifyService', modifyService);
        axios
          .patch(
              `http://localhost:3000/PassengerDetails/${this.props.passenger.id}`, modifyService
          )
          .then(res => {
              this.props.onHide();
          });          
      }
    render() {       
        return (
            <Modal
            {...this.props}
            size="lg"
            aria-labelledby="contained-modal-title-vcenter"
            centered
          >
              <Modal.Header closeButton>
                  <Modal.Title id="contained-modal-title-vcenter">
                    Modify Special Services here....
                  </Modal.Title>
                </Modal.Header>
            <ModalBody>
            <form onSubmit={e => this.handleSubmit(e, this.props.passenger)}>
                <label>
                Select your service: </label>
                    <select 
                    name="special_services"
                    onChange={e => this.handleChange(e)}>
                        <option selected value="default">Select ancillary services here..</option>
                        <option value="extraSeat">Extra Seat</option>
                        <option value="Window Seat">Window Seat</option>                        
                        <option value="delicateItem">Delicate Item</option>
                    </select>
                    <br/>
                    <label>
                Select your meals: </label>
                    <select 
                    name="special_meals"
                    onChange={e => this.handleMealChange(e)}>
                        <option selected value="default">Select meals here..</option>
                        <option value="noodles">Noodles</option>
                        <option value="chips">Chips</option>
                        <option value="vegMeal">Veg-meal</option>
                        <option value="vegBurger">Veg-Burger</option>
                    </select>
                    <Button variant="outline-primary" type="submit" >Save</Button>
                </form>
            </ModalBody>

              </Modal>
        )
    }
}

export default ModifyServices;