import React, { Component } from 'react';
import { Modal, Button, Row, Col, Form, ButtonToolbar } from 'react-bootstrap';
import axios from 'axios';
import './SeatMap.css';

const reservedSeats = [];
class SeatMap extends Component {

    constructor() {
        super();
        this.state = {
            details: [],
            rightSeats: [
                "1A", "1B", "1C",
                "2A", "2B", "2C",
                "3A", "3B", "3C",
                "4A", "4B", "4C",
                "5A", "5B", "5C",
            ],
            leftSeats: [
                "1D", "1E",
                "2D", "2E",
                "3D", "3E",
                "4D", "4E",
                "5D", "5E"
            ],
            selectedSeat: "",
            typeOfSeat: "normal",
            seatNo: "",
            isSelectedSeatDisabled: false,
            flightNo: '',
            bookedSeats: [],
            flightDetails: [],
            currentFlight: []
        };
    }
    componentDidMount() {
        console.log('i ran');
           axios.get(`http://localhost:3000/PassengerDetails/`, { params: { flightNo: this.props.flightNo } })
            .then(res => {
                const detailsP = res.data;
                this.setState({ details: detailsP })
            })        
            axios.get(`http://localhost:3000/flightLists/`, { params: { flightNo: this.props.flightNo } } )
            .then(res => {
                const currFlight = res.data;
                this.setState({ currentFlight: currFlight})
            })
    }

    componentWillReceiveProps = (prevprops, nextprops) => {
        this.setState({
            showSeatMapModal: prevprops.show
        }
      )        
    }

    selectedSeat = seatNo => {        
        this.setState({
            selectedSeat: seatNo,
            bookedSeats: [...this.state.currentFlight[0].bookedSeats, seatNo]            
        } );
      
   }
    handleCheckin = seatNo => {
        for (var i = 0; i < this.state.reservedSeats.length; i++) {
            if (this.state.reservedSeats[i] === this.state.selectedSeat) {
                return true;
            }
        }
    }

    handleSubmit = () => {
        console.log('reservedSeats', this.state.reservedSeats);
        const user = {
            id: this.props.passenger.id,
            seatType: this.state.typeOfSeat,
            checkedIn: true,
            seat_no: this.state.selectedSeat
        };
        const flight = {
                bookedSeats: this.state.bookedSeats
        };
    
        axios
            .patch(
                `http://localhost:3000/PassengerDetails/${this.props.passenger.id}`,
                user
            )
            .then(res => {
                this.props.onHide();
             });
            axios.get(`http://localhost:3000/flightLists/` )
            .then(res => {
                const flightDetails = res.data;
                res.data.map((detail => {                    
                    if (detail.flightNo === this.props.passenger.flightNo) {                        
                        axios
                         .patch(
                             `http://localhost:3000/flightLists/${detail.id}`,   
                             flight
                         )
                         .then(res => {       
                             this.setState({ currentFlight: detail})                 
                             this.props.onHide();
                             window.location.reload();        
                         } );
                     }
                }))
            })             
           
    }

    render() {
        {console.log('currentFlight', this.state.currentFlight)}
        return (
            <Modal  {...this.props}
                size="lg"
                aria-labelledby="contained-modal-title-vcenter"
                centered
            >
                <Modal.Header closeButton>
                    <Modal.Title id="contained-modal-title-vcenter">
                        Select Seat....
                  </Modal.Title>
                </Modal.Header>
                <Modal.Body className="seatMap">


                     {this.state.rightSeats.map(eachSeat => {                       
                                  
                         return ( 
                            <div style={{ margin: "0px, 5px !important", padding: "10px", display: "flex" }} className="btn-group">
                                <Button onClick={() => this.selectedSeat(eachSeat)}
                                disabled={(this.state.currentFlight[0] && this.state.currentFlight[0].bookedSeats.includes(eachSeat))
                                    ? true : false }
                                >
                                    {eachSeat}
                                </Button>
                            </div>
                        )

                    }

                    )} 

                </Modal.Body>
                <Modal.Footer>
                    <Button variant="outline-primary" onClick={() => this.handleSubmit()} >Checkin</Button>
                    <Button variant="danger" onClick={this.props.onHide}>Close</Button>
                </Modal.Footer>
            </Modal>
        )
    }

}


export default SeatMap;