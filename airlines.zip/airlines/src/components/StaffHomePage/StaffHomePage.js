import React from 'react';
import Aircraft from '../../assets/means_of_transport_02_hd_pictures_168602.jpg';
import Header from '../Header/Header';


export default function StaffHomePage() {
    return (
        <div>
        <Header />
        <h1>Welcome Staff member!!</h1>
        <img src={Aircraft} />
        <a href="/FlightLists">Go to flights</a>
    </div>

    )
}