import React, { Component } from 'react';
import './Header.css';
import firebase from 'firebase';
import {Switch, Route, Redirect , withRouter} from 'react-router-dom';

class Header extends Component {
  
    constructor(props) {
        super(props);

        this.state = {
            isSignedIn:false,
            isAdmin: false
        }

    }

    componentDidMount() {
        if(
            sessionStorage.getItem("isSignedIn") !== null &&
            sessionStorage.getItem("isAdmin") !== null
         ) {
             this.setState({
                 isSignedIn: sessionStorage.getItem("isSignedIn"),
                 isAdmin: sessionStorage.getItem("isAdmin")
             })
         }

    }

    signOut = () => {
        firebase.auth().signOut()
       // this.props.history.push('/');  
       sessionStorage.clear();
        this.setState({
            isSignedIn: false,
            isAdmin: false
        },()=> {
            window.location.href = "/"
        })
       
    }

     render() {
        return (
        <div>
            <div className="header">Welcome to Sitara Airlines</div>        
            {sessionStorage.getItem("isSignedIn") === "true" && (
                        <button onClick={this.signOut}>Log Out</button> 
                                               
                    ) }
                <div>
                    {console.log("from header", this.state.isSignedIn)}
                   
                </div>           
         </div>
            


        )

    }
    
}

export default withRouter(Header);