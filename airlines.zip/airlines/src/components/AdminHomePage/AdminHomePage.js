import React from 'react';
import Header from '../Header/Header';
import Aircraft from '../../assets/means_of_transport_02_hd_pictures_168602.jpg';


export default function AdminHomePage() {
    return (
        <div>
            <Header />
            <h1>Welcome Administrator! Please click below to manage bookings</h1>
            <img src={Aircraft} />
            <a href="/FlightLists">Go to flights</a>
         </div>

    )
}