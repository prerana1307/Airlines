import React, { Component } from "react";
import {Modal, Button, Row, Col, Form} from 'react-bootstrap';
import axios from 'axios';
import './AddNewPassenger.css';

class AddNewPassenger extends Component {
    constructor(props) {
        super()
        this.state = {
            firstName: '',
            lastName: '',
            gender: '',
            dateOfBirth: '',
            country: '',
            adderss: '',
            travelDate: '',
            travel_document: '',
            phoneNumber: '',
            emailId: '',
            documentNumber: '',
            seat_no: '',
            wheelChair: '',
            infant: ''
        }
    }
    
    changeHandler = (e) => {
        this.setState({
            [e.target.name]: e.target.value
        });
    }

    handleSubmit =(e, flightNo) => {
        console.log('submit clicked', !this.state.firstName, 'dobb', !this.state.dateOfBirth );
        e.preventDefault();
        
        if(!this.state.firstName && !this.state.dateOfBirth && !this.state.travel_document && !this.state.documentNumber && !this.state.travelDate) {
            console.log('erooorrrrr');
        }
        else {
        const newPassenger = {
            first_name: this.state.firstName,
            last_name: this.state.lastName,
            gender: this.state.gender,
            date_of_birth: this.state.dateOfBirth,
            country: this.state.country,
            adderss: this.state.adderss,
            date_of_travel: this.state.travelDate,
            travel_document: this.state.travel_document,
            mobile_no: this.state.phoneNumber,
            email_id: this.state.emailId,
            document_Number: this.state.documentNumber,
            flightNo: this.props.flightNo,
            seat_no: '',
            wheelChair: this.state.wheelChair,
            infant: this.state.infant,
            status: ''
        }
        console.log('newPassenger', newPassenger);
        axios
            .post(`http://localhost:3000/PassengerDetails`, newPassenger)
            .then(res => {
                window.location.reload();                
            })  
        }       
    }

   
    render() {
        return(
            <Modal
            {...this.props}
            size="lg"
            aria-labelledby="contained-modal-title-vcenter"
            centered
          >
            <Modal.Header closeButton>
              <Modal.Title id="contained-modal-title-vcenter">
                Add New Passenger here....
              </Modal.Title>
            </Modal.Header>
            <Modal.Body>
              
                   <form onSubmit={e => this.handleSubmit(e, this.props.flightNo)}>
                   <div className="container form-group required">
                       <label className="form-group required control-label" >
                           First Name : 
                        <input type="text" 
                            className="form-control"
                            name="firstName" 
                            placeholder="First Name" 
                            value={this.state.firstName}
                            onChange={e => this.changeHandler(e)} required="required"/>
                       </label>
                       <label className="control-label">
                           Last Name : 
                        <input type="text" 
                            name="lastName" 
                            className="form-control"
                            placeholder="Last Name" 
                            value={this.state.lastName}
                            onChange={e=>this.changeHandler(e)} />
                       </label>
                       <label className="control-label">
                           Gender : 
                         <select 
                            name="gender" 
                            className="form-control"
                            placeholder="Gender" 
                            value={this.state.gender}
                            onChange={e=>this.changeHandler(e)}>
                                    <option value="">......</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                        </select>                        
                       </label>
                       <br />
                       <label className="form-group required control-label">
                           Date Of Birth: 
                        <input type="text" 
                         className="form-control"
                                name="dateOfBirth" 
                                placeholder="Date Of Birth" 
                                value={this.state.dateOfBirth}
                                onChange={e=>this.changeHandler(e)}
                                />
                       </label>                      
                      
                       <br />
                       <label className="control-label">
                           Address: 
                        <input type="text" 
                         className="form-control"
                                name="adderss" 
                                placeholder="Address" 
                                value={this.state.adderss}
                                onChange={e=>this.changeHandler(e)} />
                       </label>                      
                       <label className="control-label">
                           Country : 
                        <input type="text" 
                         className="form-control"
                                name="country"
                                placeholder="Country" 
                                value={this.state.country}
                                onChange={e=>this.changeHandler(e)} />
                        </label>
                        <br />
                        <label className="form-group required control-label">
                           Travel Date : 
                        <input type="text" 
                        className="form-control"
                                name="travelDate" 
                                placeholder="Travel Date" 
                                value={this.state.travelDate}
                                onChange={e=>this.changeHandler(e)}    />
                       </label>
                       <label className="form-group required control-label">
                           Travel Document : 
                         <select 
                         name="travel_document" 
                         className="form-control"
                         placeholder="Travel Document" 
                         value={this.state.travel_document}
                         onChange={e=>this.changeHandler(e)}>                             
                                <option value="">......</option>
                                <option value="Aadhar">Aadhar</option>
                                <option value="Passport">Passport</option>
                        </select> 
                        </label>
                        <br />
                        <label className="control-label">
                           Phone Number: 
                        <input type="text" 
                                name="phoneNumber" 
                                className="form-control"
                                placeholder="Phone Number" 
                                value={this.state.phoneNumber}
                                onChange={e=>this.changeHandler(e)} />
                       </label>                      
                       <label className="control-label">
                           Email Id : 
                        <input type="text" 
                        className="form-control"
                            name="emailId"
                            placeholder="Email Id" 
                            value={this.state.emailId}
                            onChange={e=>this.changeHandler(e)} />
                        </label>
                        <br />
                        <label className="form-group required control-label">
                           Document Number: 
                        <input type="text" 
                        className="form-control"
                                name="documentNumber" 
                                placeholder="Document Number" 
                                value={this.state.documentNumber}
                                onChange={e=>this.changeHandler(e)} />
                       </label> 
                       <label className="control-label">
                           Infant : 
                         <select 
                            name="infant" 
                            className="form-control"
                            placeholder="Infant" 
                            value={this.state.infant}
                            onChange={e=>this.changeHandler(e)}>
                                    <option value="">......</option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                        </select>                        
                       </label>
                        <label className="control-label">
                           Wheelchair : 
                         <select 
                         name="wheelChair" 
                         className="form-control"
                         placeholder="Wheelchair" 
                         value={this.state.wheelChair}
                         onChange={e=>this.changeHandler(e)}>
                                 <option value="">......</option>
                                 <option value="Yes">Yes</option>
                                <option value="No">No</option>
                        </select> 
                        </label>
                        </div>
                        <Button variant="primary" type="submit" 
                       onClick={this.props.onHide}
                      >Save</Button>
                        
                   </form>
              
            </Modal.Body>
            
            <Modal.Footer>
               
              <Button variant="danger" onClick={this.props.onHide}>Close</Button>
            </Modal.Footer>
          </Modal>
        )
    }
    
}

export default AddNewPassenger;


