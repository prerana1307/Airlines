import React, {Component} from 'react';
import Header from '../Header/Header';
import {Link} from 'react-router-dom';
import {Button, ButtonToolbar} from 'react-bootstrap';
import AddNewPassenger from './AddNewPassenger';
import UpdatePassenger from './UpdatePassenger';
import './Passengers.css';
import axios from 'axios';

class Passengers extends Component {
    constructor(props){
        super();
        this.state = {
            data: [],
            flightNo: "",
            search: '',
            addPassengerModal: false,
            updatePassengerModal: false,
            passengerid: '',
            passengerUpdate: [],            
            isChecked: false,
            passport: false,
            address: false,
            dateOfBirth: false,

            }
         
    }

    updateSearch(event) {
        this.setState({search: event.target.value.substr(0,20)});
    }

    componentDidMount() {             
             axios.get(`http://localhost:3000/PassengerDetails`)
             .then(res => {
               const data = res.data;
               this.setState({ data });
             })
    }
   

    updateHandler = (passenger) => {
        this.setState({
            updatePassengerModal: true,
            passengerUpdate: passenger }
        )
       
    }


         addPassengerModalClose = () => this.setState({addPassengerModal: false});
        
         updatePassengerModalClose =() => this.setState({updatePassengerModal: false});

    checkBoxHandler = (e) => {
        this.setState({
            [e.target.name] : e.target.checked
        })
    }

    render() {
  
        let filterbyFlightNo = this.state.data.filter(
            (passenger) => {           
                     return passenger.flightNo === this.props.match.params.flightNo;
            }            
        );        
        
        return (
            <div>
                <Header />
                <h1>Passengers Lists ....</h1>
                <ButtonToolbar>
                    <Button variant="primary" onClick={()=> this.setState({addPassengerModal: true})}>
                        Add New Passenger
                    </Button>
                    <AddNewPassenger
                        show={this.state.addPassengerModal}
                        onHide={this.addPassengerModalClose}
                        flightNo={this.props.match.params.flightNo} />
                </ButtonToolbar>
                 <input type="checkbox" name="passport" onChange={(e) => this.checkBoxHandler(e)} checked={this.state.passport} /><label>Mandatory Document: </label>
                 <input type="checkbox" name="address" onChange={(e) => this.checkBoxHandler(e)} checked={this.state.address} /><label>Address: </label>
                 <input type="checkbox" name="dateOfBirth" onChange={(e) => this.checkBoxHandler(e)} checked={this.state.dateOfBirth} /><label>Date Of Birth: </label>

                <table className="table">
                <thead  className="thead-dark">
                    <tr>
                        <th scope="col">Flight Number</th>
                        <th scope="col">Name</th>
                        <th scope="col">Date Of Birth</th>
                        <th scope="col">Travel Date</th>
                        <th scope="col">Ancillary Services</th>
                        <th scope="col">Travel Document</th>                           
                        <th scope="col">Edit Passngers</th>            
                    </tr>
                </thead>

                {                 
                    filterbyFlightNo.map((passengers) => {                        
                       let hasPassport = (passengers.travel_document !== undefined) ? true : false;
                       let hasAddress = (passengers.address !== undefined) ? true : false;
                       let hasDOB = (passengers.date_of_birth !== undefined) ? true : false;
                        
                        return (
                            <tbody className="thead-light">
                                <tr className={(this.state.passport && hasPassport) || (this.state.address && hasAddress) || (this.state.dateOfBirth && hasDOB) ? 'hide' : ''}>

                                    <td>{passengers.flightNo}</td>
                                    <td>{passengers.first_name}  {passengers.last_name}</td> 
                                    <td>{passengers.date_of_birth}</td> 
                                    <td>{passengers.date_of_travel}</td>                                  
                                    <td>{passengers.special_services}</td>
                                    <td>{passengers.travel_document}</td>
                                    <td><ButtonToolbar>
                                        <Button variant="primary" 
                                                onClick={()=> this.updateHandler(passengers)}>
                                            Update
                                        </Button>
                                        <UpdatePassenger  
                                            show={this.state.updatePassengerModal}
                                            onHide={this.updatePassengerModalClose}                                            
                                             passengers={this.state.passengerUpdate} 
                                        
                                          />
                                    </ButtonToolbar>
                                    </td>                                    
                                </tr>

                            </tbody>
                             )
                          }
                        )

                }

                </table>

            </div>
        )
    }
   
}

export default Passengers;