import React, {Component} from 'react';
import {Modal, Button, Row, Col, Form} from 'react-bootstrap';
import axios from 'axios';

class UpdatePassenger extends Component {

    constructor(props) {
        super(props)
        this.state = {
            edit: [],
            firstName: this.props.passengers.first_name,
            lastName: '',
            gender: '',
            dateOfBirth: '',
            country: '',
            adderss: '',
            travelDate: '',
            travelDocument: '',
            phoneNumber: '',
            emailId: '',
            documentNumber: '',
            seat_no: ''
        }
        
      
    }

    componentWillReceiveProps=(prevProps,nextProps)=>{        
        this.setState({firstName: prevProps.passengers.first_name,
                       lastName: prevProps.passengers.last_name,
                       gender: prevProps.passengers.gender,
                       dateOfBirth: prevProps.passengers.date_of_birth,
                       country: prevProps.passengers.country,
                       adderss: prevProps.passengers.address,
                       travelDate: prevProps.passengers.date_of_travel,
                       travelDocument: prevProps.passengers.travel_document,
                       phoneNumber: prevProps.passengers.mobile_no,
                       emailId: prevProps.passengers.email_id,
                       documentNumber: prevProps.passengers.document_Number,
                       updatePassengerModal: prevProps.show

                            },()=>{
            })
          

    }

    changeHandler = (e) => {
        this.setState({
            [e.target.name]: e.target.value
        });
        console.log(e.target.name);
    }

     closeUpdatePassengerModal =() => this.setState({updatePassengerModal: false});

    handleSubmit =(e, passengerU) => {
        e.preventDefault();
        const updatedPassenger = {
           first_name: this.state.firstName,
           last_name: this.state.lastName,
           gender: this.state.gender,
           date_of_birth: this.state.dateOfBirth,
           country: this.state.country,
           adderss: this.state.adderss,
           date_of_travel: this.state.travelDate,
           travel_document: this.state.travel_document,
           mobile_no: this.state.phoneNumber,
           email_id: this.state.emailId,
           document_Number: this.state.documentNumber,
           flight: this.props.flightNo,
           seat_no: '',
           wheelChair: '',
           infant: '',
           status: ''

       }
             axios
                .patch(
                    `http://localhost:3000/PassengerDetails/${this.props.passengers.id}`, updatedPassenger
                )
                .then(res => {                  
                 this.props.onHide();
                 window.location.reload();
                });

         }
    

        render() {                     
            return (
                
                <Modal
                {...this.props}
                size="lg"
                aria-labelledby="contained-modal-title-vcenter"
                centered
              >
                <Modal.Header closeButton>
                  <Modal.Title id="contained-modal-title-vcenter">
                    Update Passenger here....
                  </Modal.Title>
                </Modal.Header>
                    {
                                <Modal.Body>                                
                                    <form onSubmit={e => this.handleSubmit(e, this.props.passengers)}>
                                    <div className="container">
                                        <label className='control-label'>
                                            First Name : 
                                            <input type="text" 
                                             className="form-control"
                                                name="firstName" 
                                                placeholder="First Name"                                              
                                                value={this.state.firstName}
                                                onChange={e => this.changeHandler(e)}
                                                />
                                        </label>
                                        <label className='control-label'>
                                            Last Name : 
                                            <input type="text" 
                                             className="form-control"
                                                name="lastName" 
                                                placeholder="Last Name" 
                                                value={this.state.lastName}
                                                onChange={e=>this.changeHandler(e)} />
                                        </label>
                                        
                                        <br />
                                        <label className='control-label'>
                                            Address: 
                                            <input type="text" 
                                             className="form-control"
                                                    name="adderss" 
                                                    placeholder="Address" 
                                                    value={this.state.adderss}
                                                    onChange={e=>this.changeHandler(e)} />
                                        </label>                      
                                        
                                            <br />
                                            <label className='control-label'>
                                            Travel Date : 
                                            <input type="text" 
                                             className="form-control"
                                                    name="travelDate" 
                                                    placeholder="Travel Date" 
                                                    value={this.state.travelDate}
                                                    onChange={e=>this.changeHandler(e)}    />
                                        </label>
                                        <label className='control-label'>
                                            Travel Document : 
                                            <select 
                                            name="travel_document" 
                                            className="form-control"
                                            placeholder="Travel Document" 
                                            value={this.state.travel_document}
                                            onChange={e=>this.changeHandler(e)}>
                                                        <option value="">......</option>
                                                        <option value="Aadhar">Aadhar</option>
                                                        <option value="Passport">Passport</option>
                                            </select> 
                                            </label>
                                            <br />
                                            <label className='control-label'>
                                            Phone Number: 
                                            <input type="text" 
                                             className="form-control"
                                                    name="phoneNumber" 
                                                    placeholder="Phone Number" 
                                                    value={this.state.phoneNumber}
                                                    onChange={e=>this.changeHandler(e)} />
                                        </label>                      
                                        <label className='control-label'>
                                            Email Id : 
                                            <input type="text" 
                                             className="form-control"
                                                name="emailId"
                                                placeholder="Email Id" 
                                                value={this.state.emailId}
                                                onChange={e=>this.changeHandler(e)} />
                                            </label>
                                            <br />
                                            <label className='control-label'>
                                            Document Number: 
                                            <input type="text" 
                                             className="form-control"
                                                    name="documentNumber" 
                                                    placeholder="Document Number" 
                                                    value={this.state.documentNumber}
                                                    onChange={e=>this.changeHandler(e)} />
                                        </label> 
                                        </div>
                                        <Button variant="primary" type="submit" >Save</Button>
                                    </form>
                                
                                </Modal.Body>                          
                        }
            
       
                <Modal.Footer>
                   
                  <Button variant="danger" onClick={this.props.onHide}>Close</Button>
                </Modal.Footer>
              </Modal>
            )
        }


}

export default UpdatePassenger;