import React, {Component} from 'react';
import Header from '../Header/Header';
import axios from 'axios';
import SeatMap from '../SeatMap/SeatMap';
import {Modal, Button, Row, Col, Form, ButtonToolbar} from 'react-bootstrap';
import ModifyServices from '../SeatMap/ModifyServices';
import './Passengers.css';
import classNames from "classnames";

class PassengerCheckinDetail extends Component{
    constructor(props){
        super();
        this.state = {
            data: [],
            flightNo: "",
            passengerid: '', 
            passengers: [],
            showSeatMapModal: false,
            showModifyServiceModal: false,
            wheelchair: false,
            infant: false,
            seat: false,
            details: [],
            toBeremovedSeat: "",
            removeReservedSeat: [],
            currentFlight: []   ,
            flightID: ""                    
        }
        
    }

    componentDidMount() {       
        axios.get(`http://localhost:3000/PassengerDetails/`, { params: { flightNo: this.props.match.params.flightNo} })
        .then(res => {           
            const passengers = res.data;
            this.setState({ passengers })
        })   
         
        axios.get(`http://localhost:3000/flightLists/`, { params: { flightNo: this.props.match.params.flightNo } } )
        .then(res => {
            const flightID = res.data[0].id;
            const currentFlight = res.data[0].bookedSeats;           
            this.setState({ currentFlight, flightID})
        });   
        }
    
    seatMapping = (p) => {
        
        this.setState({
            showSeatMapModal: true,
            passenger: p
        })
       
    }

    modifyService = (p) => {
        this.setState({
            showModifyServiceModal: true,
            passenger: p,            
        })
    }

    offloadSeat = (e, passengerDetail) => {
        e.preventDefault();
        this.setState({
            passenger: passengerDetail,
            toBeremovedSeat: passengerDetail.seat_no                             
        })
        const removeSeat = {
            seat_no: ''
         }    
       this.state.currentFlight.map((seat) => {
          if(seat === passengerDetail.seat_no) {
              const index = this.state.currentFlight.indexOf(seat);
                
                this.setState({
                    currentFlight: this.state.currentFlight.splice(index, 1)
                 })
                 
                 const removeSeatInFlight = {
                     bookedSeats: this.state.currentFlight};
                 
                 axios.patch(`http://localhost:3000/flightLists/${this.state.flightID}`, removeSeatInFlight )
                 .then(res => {
                     
                 })
          };
       })
                axios
                .patch(
                    `http://localhost:3000/PassengerDetails/${passengerDetail.id}`, removeSeat
                )
                .then(res => {              
                    window.location.reload(); 
                });               
              
     }
            
            checkBoxHandler = (e) => {                
                this.setState({
                    [e.target.name] : e.target.checked
                })
            }



    render(){
        
        let filterbyFlightNo = this.state.passengers.filter(
            (passenger) => {                
                return passenger.flightNo == this.props.match.params.flightNo;
            }
            
        );

        let seatMapModalClose =() => this.setState({showSeatMapModal: false});
        let modifyServiceModalClose =() => this.setState({showModifyServiceModal: false});        
        return (
            <div>
                <Header />
                <h1> Check in details of Passengers ... </h1>
                <input type="checkbox" name="wheelchair" onChange={(e) => this.checkBoxHandler(e)} checked={this.state.wheelchair} /><label>Wheelchair </label>
                <input type="checkbox" name="infant" onChange={(e) => this.checkBoxHandler(e)} checked={this.state.infant} /><label>Infant </label>
                <input type="checkbox" name="seat" onChange={(e) => this.checkBoxHandler(e)} checked={this.state.seat} /><label>Checked In </label>
                <table className="table">
                        <thead  className="thead-light">
                            <tr>
                                <th scope="col">First Name</th>
                                <th scope="col">Last Name</th>
                                <th scope="col">Seat Type</th>
                                <th scope="col">Seat No</th>
                                <th scope="col">Status</th>
                                <th scope="col">Wheelchair</th>
                                <th scope="col">Infant</th>
                                <th scope="col">Ancillary Services</th>
                                <th scope="col">Special Meals</th>
                                <th scope="col">Checkin</th>                           
                                <th scope="col">Offload</th>   
                                <th scope="col">Seat Change</th>
                                <th scope="col">Modify Services</th>         
                            </tr>
                        </thead>

                        {
                    filterbyFlightNo.map((passengers) => {
                        let hasWheelchair = (passengers.wheelChair !== 'Yes') ? true : false;
                        let hasInfant = (passengers.infant !== 'Yes') ? true : false;
                        let hasSeat = (passengers.seat_no === 'NA')  || (passengers.seat_no === undefined)
                                      || (passengers.seat_no === '') ? true : false;
                      
                        const filterHide = (this.state.wheelchair && hasWheelchair) || 
                        (this.state.infant && hasInfant) ||
                        (this.state.seat && hasSeat) ? 'hide' : ''
                        const checkinStatus =  (passengers.seat_no === 'NA') || (passengers.seat_no === undefined)
                                                || (passengers.seat_no === '')  ? 'notCheckedIn' : 'checkedIn'
                        
                        return (
                            <tbody className="thead-dark">
                                <tr className={`${filterHide} ${checkinStatus}`}
                                    >
                                    <td>{passengers.first_name}</td>
                                    <td>{passengers.last_name}  </td> 
                                    <td>{passengers.seatType}</td> 
                                    <td>{passengers.seat_no}</td>                                  
                                    <td>{passengers.status}</td>
                                    <td>{passengers.wheelChair}</td>
                                    <td>{passengers.infant}</td>
                                    <td>{passengers.special_services}</td>
                                    <td>{passengers.special_meals}</td>
                                    <td>
                                    <ButtonToolbar>
                                        <Button variant="primary" 
                                                onClick={()=> this.seatMapping(passengers)}
                                                disabled={(passengers.seat_no) ? true : false}>
                                            Checkin
                                        </Button>                                       
                                    </ButtonToolbar>
                                    </td>
                                    <td>
                                    <ButtonToolbar>
                                        <Button variant="primary" 
                                                onClick={(e)=> this.offloadSeat(e, passengers)}
                                                disabled={(passengers.seat_no) ? false : true}>
                                            Offload
                                        </Button>                                        
                                    </ButtonToolbar>
                                    </td>
                                    <td>
                                    <ButtonToolbar>
                                        <Button variant="primary" 
                                                onClick={()=> this.seatMapping(passengers)}
                                                disabled={(passengers.seat_no) ? false : true}>
                                            Change Seat
                                        </Button>
                                       
                                    </ButtonToolbar>
                                    </td>
                                    <td>
                                    <ButtonToolbar>
                                        <Button variant="primary" 
                                                onClick={()=> this.modifyService(passengers)}>
                                            Modify Service
                                        </Button>
                                        <ModifyServices 
                                            show={this.state.showModifyServiceModal}
                                            passenger={this.state.passenger}
                                            onHide={modifyServiceModalClose}/>
                                    </ButtonToolbar>
                                    </td>
                                                             
                                </tr>

                            </tbody>
                             )
                          }
                        )
                }
                
                </table>

                <SeatMap 
                          show={this.state.showSeatMapModal}
                          passenger={this.state.passenger}
                          onHide={seatMapModalClose}
                          flightNo={this.props.match.params.flightNo}                          
                      />

            </div>
        )
    }
}

export default PassengerCheckinDetail;