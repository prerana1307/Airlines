import React, {Component} from 'react';
import firebase from 'firebase';
import StyledFirebaseAuth from 'react-firebaseui/StyledFirebaseAuth';
import axios from 'axios';
import {Switch, Route, Redirect, withRouter} from 'react-router-dom';


firebase.initializeApp({
    apiKey: "AIzaSyDk6p6kY1DKd_Jvn-WJBu5U6LutDTyzEAA",
    authDomain: "airline-201-20387.firebaseapp.com"
})

class Login extends Component {
        constructor(props) {           
            super(props)
            console.log(this.props.history);
                this.state = {
                    isSignedin: false,
                    isAdmin: true
                }
                this.loginHandler = this.loginHandler.bind(this)
         } 

        uiConfig = {
            signInFlow:  "popup",
            signInOptions : [
                firebase.auth.GoogleAuthProvider.PROVIDER_ID,
                firebase.auth.EmailAuthProvider.PROVIDER_ID
            ],

            callbacks: {
                signInSuccess: () => false
            }
        }

          loginHandler () {                            
            firebase.auth().onAuthStateChanged(user => {
                console.log('test user', !!user);
                this.setState({
                    isSignedIn: !!user
                })            
                if(this.state.isSignedIn){
                    console.log("inside if")
                    axios.get(`http://localhost:3000/loginDetails`)
                        .then(res => {
                            for (let i = 0; i < res.data.length; i++) {
                                if(res.data[i].email === firebase.auth().currentUser.email){                               
                                sessionStorage.setItem("isAdmin", res.data[i].isAdmin);
                                sessionStorage.setItem("isSignedIn", true);
                                
                                this.setState({
                                    isAdmin: res.data[i].isAdmin
                                }) 
                                if(this.state.isAdmin === true)
                                {
                                    this.props.history.push('/AdminHomePage')
                                }
                                else{
                                    this.props.history.push('/StaffHomePage')
                                }
                                console.log("isAdmin", this.state.isAdmin)
                                }

                            }
                        })

                }
        
                console.log("user", user)
                console.log("testing", this.state.isSignedIn)               
             })
            
         }

    render() {
        
            {console.log("inside render", this.state.isSignedIn) }
        
        return (
            <div>
                {this.state.isSignedIn === false && (
                      <StyledFirebaseAuth
                      uiConfig={this.uiConfig}
                      firebaseAuth={firebase.auth()}
                  />
                )
             }

            <button onClick={this.loginHandler}>Login</button>
            </div>
        )
    }

}


export default withRouter(Login);