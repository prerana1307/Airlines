import React from 'react';
import Header from '../Header/Header';
import AirlineImg from '../../assets/undraw_aircraft_fbvl.png';
import Login from '../LoginPage/Login';


const HomePage = () => {
    return (
        <div>
            <Header />
            <Login />
            
            
            <img src={AirlineImg} />
           
        </div>

    )
}

export default HomePage;