import React, {Component} from 'react';
import Header from '../Header/Header';
import {Link} from 'react-router-dom';
import Passengers from '../Passengers/PassengersList';
import Services from '../Services/Services';
import {Button, ButtonToolbar} from 'react-bootstrap';
import Meals from '../Services/Meals';

class FlightLists extends Component {
    constructor() {
        super();
        this.state = {
            data: [],
            search: '',
            addSpecialServicesModal: false,
            addSpecialMealsModal: false
        };
    }

    updateSearch(event) {
        this.setState({search: event.target.value.substr(0,20)});
    }
   

    componentDidMount() {
        let url = "http://localhost:3000/flightLists"
        fetch(url)
            .then(resp => resp.json())
            .then(data => this.setState({data}));                 
    }

    
    addServicesHandler =() => {
        this.setState({
            addSpecialServicesModal: true
        })
        console.log('Modal clicked');
    }

    specialService = (f) => {
        this.setState({
            addSpecialServicesModal: true,
            flight: f
        }, ()=> {console.log("modal button ..... ", this.state.flight.special_services)})
        
    }
    specialMeal = (f) => {
        this.setState({
            addSpecialMealsModal: true,
            flight: f
        }, ()=> {console.log("modal button ..... ", this.state.flight.special_services)})
        
    }

    addSpecialServicesModalClose = () => this.setState({addSpecialServicesModal: false});
    addSpecialMealsModalClose = () => this.setState({addSpecialMealsModal: false});

    render() {        
        let searchFlights = this.state.data.filter(
            (flight) => {                
                return flight.departureDate.indexOf(this.state.search) !== -1;                
            }
        );
        console.log('flights', searchFlights);       
        
        return(
            <div>
                <Header />
                <div>
                <p>Search</p>
                <input type="text"
                    value={this.state.search}
                    onChange={this.updateSearch.bind(this)}
                    ></input>
                </div>
            <div>Here you go.....</div>         
                      

            <table className="table">
                <thead  className="thead-dark">
                    <tr>
                    <th scope="col">Flight Number</th>
                    <th scope="col">Airline</th>
                    <th scope="col">Departure</th>
                    <th scope="col">Arrival</th>
                    <th scope="col">Departure Time</th>
                    <th scope="col">Arrival Time</th>
                    <th scope="col">Passengers Details</th>
                    {sessionStorage.getItem("isAdmin") === "true" ? (
                        <div>
                    <th scope="col">Add/Update Special Service</th>
                    <th scope="col">Add/update Meals</th>
                    </div>
                    ) : (null)
                }
                    </tr>
                </thead>
                
                    {
                        
                        searchFlights.map((flightLists) => {     
                            console.log('status of data', flightLists.special_services)                       
                                return (
                                <tbody className="thead-light">
                                    <tr>
                                        <td>{flightLists.flightNo}</td>
                                        <td>{flightLists.airline}</td>
                                        <td>{flightLists.departureStation}</td>
                                        <td>{flightLists.arrivalStation}</td>
                                        <td>{flightLists.departureDate}</td>
                                        <td>{flightLists.arrivalDate}</td>
                                        {console.log("passengerList", sessionStorage.getItem("isSignedIn"))}
                                        {sessionStorage.getItem("isAdmin") === "true" ? (
                                                <td><Link to={`/PassengersLists/${flightLists.flightNo}`}>View Passengers List</Link></td>
                                        ) :
                                        (
                                            <td><Link to={`/PassengerCheckinDetail/${flightLists.flightNo}`}>View Checkin Details</Link></td>
                                        )
                                      }
                                       {sessionStorage.getItem("isAdmin") === "true" ? (
                                           <div>
                                        <td> <ButtonToolbar>
                                        <Button onClick={()=> this.specialService(flightLists)}
                                        >Add/Update Special Services</Button>
                                        <Services
                                            show={this.state.addSpecialServicesModal}
                                            onHide={this.addSpecialServicesModalClose}
                                            flightLists={this.state.flight}
                                            
                                            />
                                        </ButtonToolbar></td>
                                        <td>
                                        <ButtonToolbar>
                                            <Button onClick={()=> this.specialMeal(flightLists)}>Add/Update Meals</Button>
                                            <Meals
                                            show={this.state.addSpecialMealsModal}
                                            onHide={this.addSpecialMealsModalClose}
                                            flightLists={this.state.flight}
                                            />
                                        </ButtonToolbar>  
                                        </td>
                                        </div>
                                       ) : (null)
                                  }            
                                    </tr>
                                </tbody>                                
                                )
                            } )
                       
                    }
                 
            </table>
                   
            
            </div>

        )
    }
}

export default FlightLists;