Steps to start the project:

1. Unzip the folder
2. run npm install
3. Start json server in another terminal using below command :
	json-server --watch db.json
4. Run npm start

Steps to create login in db.json:
1. Enter your login details in below format and put it in db.json under "loginDetails"

{
      "id": 1,
      "firstName": "Prerana",
      "lastName": "Rawat",
      "email": "rprerana2010@gmail.com",
      "isAdmin": false
    },
2. Email id should be valid.
3. Mark "isAdmin" true or false to check airline staff and admin flow.